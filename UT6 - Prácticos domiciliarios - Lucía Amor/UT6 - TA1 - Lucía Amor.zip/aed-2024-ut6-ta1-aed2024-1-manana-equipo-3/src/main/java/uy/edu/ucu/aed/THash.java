package uy.edu.ucu.aed;

public class THash implements IHash{
    private int[] T;


    public THash(int[] T) {
        this.T = new int[T.length];
        System.arraycopy(T, 0, this.T, 0, T.length);
    }

    public int buscar(int unaClave) {
        int comparaciones = 0;
        int i = 0;
        int j = funcionHashing(unaClave) % T.length;
        while (T[j] != 0 && i < T.length) {
            comparaciones++;
            if (T[j] == unaClave) {
                return Math.abs(comparaciones);
            }
            i++;
            j = (funcionHashing(unaClave) + i) % T.length;
        }
        return -Math.abs(comparaciones);
    }

    public int insertar(int unaClave) {
        int i = 0;
        int j = funcionHashing(unaClave) % T.length;
        while (i < T.length - 1 && T[j] != 0) {
            i++;
            j = (funcionHashing(unaClave) + i) % T.length;
        }
        if (i < T.length) {
            T[j] = unaClave;
            return j;
        } else {
            throw new UnsupportedOperationException("Hash table overflow");
        }
    }

    public int funcionHashing(int unaClave) {
        return unaClave;
    }
}