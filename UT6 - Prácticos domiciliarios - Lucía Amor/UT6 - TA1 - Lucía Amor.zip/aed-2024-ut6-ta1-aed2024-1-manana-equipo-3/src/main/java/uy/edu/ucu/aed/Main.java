/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uy.edu.ucu.aed;

/**
 *
 * @author jechague
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        THash tabla = new THash(new int[223]);
        ManejadorArchivosGenerico manager = new ManejadorArchivosGenerico();
        String nombreArchivoInsertar = "src/main/java/uy/edu/ucu/aed/claves_insertar.txt";
        String[] claves = manager.leerArchivo(nombreArchivoInsertar);
        for (int i = 0; i < claves.length; i++) {
            int clave = Integer.parseInt(claves[i]);
            tabla.insertar(clave);
        }
        
        String nombreArchivoBuscar = "src/main/java/uy/edu/ucu/aed/claves_buscar.txt";
        String[] clavesBuscar = manager.leerArchivo(nombreArchivoBuscar);
        int promedio = 0;
        for (int i = 0; i < clavesBuscar.length; i++) {
            int clave = Integer.parseInt(clavesBuscar[i]);
            int comparaciones = tabla.buscar(clave);
            boolean encontrado = comparaciones > 0;
            comparaciones = Math.abs(comparaciones);
            promedio++;
            System.out.println("Clave: " + clave + " Comparaciones: " + comparaciones + " Encontrado: " + encontrado);
        }
        System.out.println("Promedio: " + promedio/clavesBuscar.length);
        // Buscar en la tabla creada anteriormente las claves indicadas en el archivo "claves_buscar.txt"
    }
}