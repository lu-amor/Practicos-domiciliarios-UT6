package uy.edu.ucu.aed;

import org.junit.Before;
import org.junit.Test;
import java.util.List;

import static org.junit.Assert.*;

public class TArbolTrieTest_JUnit4 {

}