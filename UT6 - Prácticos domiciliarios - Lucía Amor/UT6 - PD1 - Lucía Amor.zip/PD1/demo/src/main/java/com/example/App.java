package com.example;

public class App{

    private static TArbolTrieHashMap trie;
    private static final int REPETICIONES = 20;
    public static void main( String[] args )
    {
        ManejadorArchivosGenerico manager = new ManejadorArchivosGenerico();
        String[] lineas = manager.leerArchivo("demo/src/main/java/com/example/listado-general_desordenado.txt");
        trie = new TArbolTrieHashMap();
        TArbolTrie trie2 = new TArbolTrie();
        for (String linea : lineas) {
            trie.insertar(linea);
            trie2.insertar(linea);
        }

        String[] prefijosBuscar = new String[1];
        prefijosBuscar[0] = "cas";

        Medible[] predecibles = new Medible[2];
        int j = 0;
        predecibles[j++] = new MedicionPredecirTrie(trie2);
        predecibles[j++] = new MedicionPredecirTrieHashMap(trie);
        Medicion mi2;
    j = 0;
        Object[] params2 = {REPETICIONES, prefijosBuscar};
        String[] lineas2 = new String[3];
        lineas2[j++] = "algoritmo, tiempo, memoria";
        for (Medible m2: predecibles){
            mi2 = m2.medir(params2);
            mi2.print();
            lineas2[j++] = mi2.getTexto()+", " + mi2.getTiempoEjecucion().toString() + ", " + mi2.getMemoria().toString();
        }
        
        ManejadorArchivosGenerico.escribirArchivo("demo/src/main/java/com/example/salida.txt", lineas2);
    }
}